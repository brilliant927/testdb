/*

  Copyright 2022 Hubbell Incorporated

  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.

  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.

 */

package com.idevicesinc.sweetblue.internal;


import com.idevicesinc.sweetblue.BleStatuses;
import com.idevicesinc.sweetblue.internal.android.P_DeviceHolder;


abstract class PA_Task_ConnectOrDisconnectServer extends PA_Task_RequiresBleOn
{
	private final PE_TaskPriority m_priority;
	private final boolean m_explicit;
	final P_DeviceHolder m_nativeDevice;

	protected int m_gattStatus = BleStatuses.GATT_STATUS_NOT_APPLICABLE;

	PA_Task_ConnectOrDisconnectServer(final IBleServer server, final P_DeviceHolder device, final I_StateListener listener, final boolean explicit, final PE_TaskPriority priority)
	{
		super(server, listener);

		m_explicit = explicit;
		m_priority = priority;
		m_nativeDevice = device;
	}

	public boolean isFor(final IBleServer server, final String macAddress)
	{
		return server.equals(getServer()) && macAddress.equals(m_nativeDevice.getAddress());
	}

	@Override public PE_TaskPriority getPriority()
	{
		return m_priority;
	}

	@Override public boolean isExplicit()
	{
		return m_explicit;
	}

	public int getGattStatus()
	{
		return m_gattStatus;
	}
}
