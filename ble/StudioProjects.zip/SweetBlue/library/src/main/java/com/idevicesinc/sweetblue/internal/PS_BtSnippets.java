/*
 
  Copyright 2022 Hubbell Incorporated
 
  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
 
  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 
  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 
 */

package com.idevicesinc.sweetblue.internal;


/**
 * Just some commented out snippets that I don't feel like digging through revision history for if I ever need them again.
 */
final class PS_BtSnippets
{
//	private void createBondIfNeeded(BleCharacteristic characteristic)
//	{
//		if( isInAnyState(BONDED, BONDING) )  return;
//		
//		BluetoothGattCharacteristic characteristic_native = characteristic.getNativeLayer();
//		
//		if( U_Bt.requiresBonding(characteristic_native) )
//		{
//			if( (characteristic_native.getProperties() & BluetoothGattCharacteristic.PROPERTY_SIGNED_WRITE) != 0x0 )
//			{
//				m_logger.e("PROPERTY_SIGNED_WRITE " + m_logger.charName(characteristic_native.getUuid()));
//			}
//			if( (characteristic_native.getPermissions() & BluetoothGattCharacteristic.PERMISSION_READ_ENCRYPTED) != 0x0 )
//			{
//				m_logger.e("PERMISSION_READ_ENCRYPTED " + m_logger.charName(characteristic_native.getUuid()));
//			}
//			if( (characteristic_native.getPermissions() & BluetoothGattCharacteristic.PERMISSION_READ_ENCRYPTED_MITM) != 0x0 )
//			{
//				m_logger.e("PERMISSION_READ_ENCRYPTED_MITM " + m_logger.charName(characteristic_native.getUuid()));
//			}
//			if( (characteristic_native.getPermissions() & BluetoothGattCharacteristic.PERMISSION_WRITE_ENCRYPTED) != 0x0 )
//			{
//				m_logger.e("PERMISSION_WRITE_ENCRYPTED " + m_logger.charName(characteristic_native.getUuid()));
//			}
//			if( (characteristic_native.getPermissions() & BluetoothGattCharacteristic.PERMISSION_WRITE_ENCRYPTED_MITM) != 0x0 )
//			{
//				m_logger.e("PERMISSION_WRITE_ENCRYPTED_MITM " + m_logger.charName(characteristic_native.getUuid()));
//			}
//			if( (characteristic_native.getPermissions() & BluetoothGattCharacteristic.PERMISSION_WRITE_SIGNED) != 0x0 )
//			{
//				m_logger.e("PERMISSION_WRITE_SIGNED " + m_logger.charName(characteristic_native.getUuid()));
//			}
//			if( (characteristic_native.getPermissions() & BluetoothGattCharacteristic.PERMISSION_WRITE_SIGNED_MITM) != 0x0 )
//			{
//				m_logger.e("PERMISSION_WRITE_SIGNED_MITM " + m_logger.charName(characteristic_native.getUuid()));
//			}
			
//			createBond();
//		}
//	}
}
